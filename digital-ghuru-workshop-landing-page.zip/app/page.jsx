'use client';

import { useEffect, useState } from 'react';

const Arrow = () => <span className="arrow">↗</span>;
const Spark = () => <span className="spark">✦</span>;

function Reveal({ children, className = '' }) {
  return <div className={`reveal ${className}`}>{children}</div>;
}

export default function Home() {
  const [open, setOpen] = useState(null);
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add('visible')), { threshold: .12 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);
  const faqs = [
    ['Who can attend?', 'Students from every department can join - including arts, science, commerce, management, media and engineering. No prior marketing or technical knowledge is needed.'],
    ['Will students get a certificate?', 'Yes. Every participant receives a Workshop Participation Certificate after completing the program.'],
    ['Is this a theory-only session?', 'No. The workshop is built around live demonstrations, real-time examples, hands-on exercises and practical AI workflows.'],
    ['Can colleges host this for their students?', 'Absolutely. This workshop is specially designed for colleges and educational institutions that want to build future-ready skills on campus.']
  ];
  return <main>
    <nav className="nav"><a className="brand" href="#top"><i>dg</i><span>Digital<br/><b>Ghuru</b></span></a><div className="navlinks"><a href="#agenda">Agenda</a><a href="#outcomes">Outcomes</a><a href="#trainer">Why us</a></div><a className="button small" href="#register">Register now <Arrow/></a></nav>

    <section id="top" className="hero grid-bg">
      <Reveal className="hero-copy"><p className="eyebrow"><Spark/> for colleges & future builders</p><h1>Make your<br/>students <em>AI-ready.</em></h1><p className="lede">The hands-on Digital Marketing AI Tools Workshop that turns curiosity into career-ready digital confidence.</p><div className="hero-actions"><a className="button" href="#register">Reserve your seat <Arrow/></a><a className="text-link" href="#agenda">Explore the workshop ↓</a></div><div className="trusted"><span className="avatars">✦ &nbsp; ● &nbsp; ✿</span><span>Built for the next generation<br/><b>of digital leaders</b></span></div></Reveal>
      <Reveal className="hero-visual modern-photo"><div className="photo-orbit"></div><img src="/assets/ai-student-cutout.png" alt="Student exploring the future of AI"/><div className="photo-caption"><Spark/> Career-ready digital skills<br/><b>Start with curiosity.</b></div><div className="photo-stamp">AI<br/><small>READY</small></div></Reveal>
    </section>

    <section className="marquee"><span>CREATE SMARTER</span><i>✦</i><span>MARKET FASTER</span><i>✦</i><span>GROW WITH AI</span><i>✦</i><span>CREATE SMARTER</span></section>

    <section className="section problem"><Reveal><p className="eyebrow orange">the gap is real</p><h2>Degrees open doors.<br/><em>Digital fluency</em> opens futures.</h2></Reveal><Reveal className="problem-side"><p>Today’s students need more than academic knowledge. They need the confidence to use the tools already reshaping how brands, startups and creators work.</p><div className="problem-points"><span>Industry-aware</span><span>Practical</span><span>Career-first</span></div></Reveal></section>

    <section className="section promise"><Reveal><div className="label-block">THE WORKSHOP<br/>PROMISE <Spark/></div></Reveal><Reveal><h2>Not another lecture.<br/><em>A launchpad.</em></h2><p className="lede">A beginner-friendly, high-energy experience where students see AI in action, make things themselves and discover where their skills can take them. From first prompt to finished marketing creative, every session gives learners a clear sense of what modern work feels like.</p></Reveal><Reveal className="promise-art"><img src="/assets/workshop-detail.png" alt="Digital marketing AI workshop visual"/><span className="image-note">Ideas become<br/><b>work people see.</b></span></Reveal></section>

    <section className="section audience"><Reveal><p className="eyebrow">made for everyone</p><h2>One room.<br/><em>Every discipline.</em></h2><p className="audience-intro">Students from science, commerce, arts, management and technology bring different perspectives. AI gives them a shared creative language.</p></Reveal><Reveal className="chips"><span>BBA / MBA</span><span>Engineering</span><span>Arts & Science</span><span>Media & Comms</span><span>Commerce</span><span>Entrepreneurs</span><span>Any curious student</span><p>No experience required - just an appetite for what’s next.</p></Reveal><Reveal className="audience-photo"><img src="/assets/workshop-poster.png" alt="AI workshop programme"/></Reveal></section>

    <section id="agenda" className="section agenda"><Reveal><p className="eyebrow orange">your learning arc</p><h2>Two days. Seven<br/><em>future-forward</em> sessions.</h2></Reveal><div className="days"><Reveal className="day blue"><div className="day-num">01</div><div><p className="day-kicker">DAY ONE · FOUNDATIONS</p><h3>Understand the new marketing playbook.</h3><ul><li>Digital Marketing essentials</li><li>AI in modern marketing</li><li>AI content creation tools</li><li>AI design tools & creative workflows</li></ul></div><div className="day-art">✦<small>MAKE<br/>IT REAL</small></div></Reveal><Reveal className="day gold"><div className="day-num">02</div><div><p className="day-kicker">DAY TWO · MOMENTUM</p><h3>Create, share and see where it can lead.</h3><ul><li>AI video tools demo</li><li>Social media marketing with AI</li><li>Careers, freelancing & entrepreneurship</li></ul></div><div className="day-art">◉<small>YOUR<br/>MOVE</small></div></Reveal></div></section>

    <section className="method"><Reveal><div className="method-copy"><p className="eyebrow">learn by doing</p><h2>Watch it.<br/>Try it.<br/><em>Own it.</em></h2></div></Reveal><Reveal className="method-cards"><article><span>01</span><h3>Live tool demos</h3><p>See the workflows behind content, design, video and social in real time.</p></article><article><span>02</span><h3>Guided making</h3><p>Turn prompts and ideas into tangible marketing creative.</p></article><article><span>03</span><h3>Career context</h3><p>Connect new skills with the opportunities shaping the world of work.</p></article></Reveal></section>

    <section id="outcomes" className="section outcomes"><Reveal><p className="eyebrow orange">what leaves with them</p><h2>More than notes.<br/><em>Real momentum.</em></h2></Reveal><div className="outcome-grid"><Reveal><div className="outcome featured"><span>01</span><h3>AI tool awareness</h3><p>Know the tools transforming marketing teams today.</p><b>✦</b></div></Reveal>{['Basic marketing knowledge','Creative confidence','Career guidance','Future-ready digital skills','Participation certificate'].map((x,i)=><Reveal key={x}><div className="outcome"><span>0{i+2}</span><h3>{x}</h3><p>Practical exposure students can build on.</p></div></Reveal>)}</div></section>

    <section id="trainer" className="section trainer"><Reveal className="trainer-art"><img src="/assets/ai-student-cutout.png" alt="AI learner"/><div className="trainer-cut"><div>digital<br/><b>ghuru</b></div><span>YOUR GROWTH PARTNER</span></div></Reveal><Reveal><p className="eyebrow">why digital ghuru</p><h2>We teach what the<br/><em>industry uses.</em></h2><p className="lede">Digital Ghuru helps students bridge the distance between academic learning and industry expectations - with accessible instruction, current tools and a genuinely practical point of view. Students don’t just hear about the digital world; they make their first moves in it.</p><div className="stats"><span><b>Hands-on</b> learning</span><span><b>Industry</b> context</span><span><b>Career</b> minded</span></div></Reveal></section>

    <section className="section date"><Reveal><p className="eyebrow orange">save the dates</p><h2>Give your students<br/>a head start on <em>tomorrow.</em></h2></Reveal><Reveal className="date-card"><span>WORKSHOP DATE</span><strong>02 <i>&</i> 03</strong><b>OCTOBER 2026</b><hr/><p>College workshop · AI-powered digital skills</p><a className="button" href="#register">Enquire for your college <Arrow/></a></Reveal></section>

    <section id="register" className="register"><Reveal><div><p className="eyebrow">bring it to your campus</p><h2>Let’s build<br/><em>future-ready</em><br/>students.</h2><p>Tell us about your institution and our team will help you plan the right workshop experience.</p></div></Reveal><Reveal><form onSubmit={(e)=>e.preventDefault()}><label>YOUR NAME<input placeholder="Name" required /></label><label>COLLEGE / INSTITUTION<input placeholder="Institution name" required /></label><label>PHONE NUMBER<input placeholder="Your phone number" required /></label><label>EMAIL ADDRESS<input placeholder="you@college.edu" type="email" required /></label><button className="button" type="submit">Send enquiry <Arrow/></button><small>Or WhatsApp us at <b>88259 48859</b></small></form></Reveal></section>

    <section className="section faq"><Reveal><p className="eyebrow orange">good questions</p><h2>Before you ask.</h2></Reveal><div>{faqs.map(([q,a],i)=><Reveal key={q}><button className="faq-row" onClick={()=>setOpen(open===i?null:i)}><span>{q}</span><b>{open===i?'−':'+'}</b></button>{open===i&&<p className="faq-answer">{a}</p>}</Reveal>)}</div></section>

    <section className="final"><Reveal><p>the future is not waiting.</p><h2>Neither should<br/><em>your students.</em></h2><a className="button" href="#register">Book the workshop <Arrow/></a></Reveal></section>
    <footer><a className="brand" href="#top"><i>dg</i><span>Digital<br/><b>Ghuru</b></span></a><span>AI Career Transformation Academy</span><span>www.digitalghuru.com</span><a href="tel:8825948859">88259 48859</a></footer>
  </main>;
}
