import './globals.css';
import './redesign.css';
import './remove-dots.css';

export const metadata = {
  title: 'Digital Marketing AI Tools Workshop | Digital Ghuru',
  description: 'An AI-powered digital marketing workshop for college students.'
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
